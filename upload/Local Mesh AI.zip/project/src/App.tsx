import { useState, useEffect } from 'react';
import { Sun, Moon, Network } from 'lucide-react';
import type { ScreenView, Conversation, ScreenTab } from './types';
import { machines as initialMachines, conversations as initialConversations } from './data';
import { BottomNav } from './BottomNav';
import { WelcomeScreen } from './screens/WelcomeScreen';
import { MachinesScreen, MachineDetailScreen } from './screens/MachinesScreen';
import { ChatScreen } from './screens/ChatScreen';
import { ChatsScreen } from './screens/ChatsScreen';
import { LibraryScreen } from './screens/LibraryScreen';
import { SettingsScreen } from './screens/SettingsScreen';
import { PairingScreen } from './screens/PairingScreen';

export default function App() {
  const [view, setView] = useState<ScreenView>({ type: 'welcome' });
  const [conversations, setConversations] = useState<Conversation[]>(initialConversations);
  const [isDark, setIsDark] = useState(false);
  const [scanning, setScanning] = useState(false);

  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDark]);

  const updateConversation = (conv: Conversation) => {
    setConversations((prev) => {
      const idx = prev.findIndex((c) => c.id === conv.id);
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = conv;
        return copy;
      }
      return [conv, ...prev];
    });
  };

  const createNewChat = (machineId: string) => {
    const machine = initialMachines.find((m) => m.id === machineId);
    if (!machine) return;
    const loadedModel = machine.models.find((m) => m.loaded) || machine.models[0];
    const newConv: Conversation = {
      id: `conv-${Date.now()}`,
      title: 'New chat',
      machineId: machine.id,
      machineName: machine.name,
      modelName: loadedModel?.name || 'Unknown',
      path: machine.path,
      autoRouting: true,
      messages: [],
      draft: '',
      lastActivity: Date.now(),
    };
    setConversations((prev) => [newConv, ...prev]);
    setView({ type: 'chat', conversationId: newConv.id });
  };

  const handleFindLocal = () => {
    setScanning(true);
    setTimeout(() => {
      setScanning(false);
      setView({ type: 'tab', tab: 'machines' });
    }, 2000);
  };

  const renderScreen = () => {
    switch (view.type) {
      case 'welcome':
        return (
          <WelcomeScreen
            onFindLocal={handleFindLocal}
            onConnectRemote={() => setView({ type: 'pairing' })}
            onShowFound={handleFindLocal}
            scanning={scanning}
          />
        );

      case 'pairing':
        return (
          <PairingScreen
            onBack={() => setView({ type: 'welcome' })}
            onComplete={() => setView({ type: 'tab', tab: 'machines' })}
          />
        );

      case 'tab': {
        if (view.tab === 'chats') {
          return (
            <ChatsScreen
              conversations={conversations}
              onOpenChat={(id) => setView({ type: 'chat', conversationId: id })}
              onNewChat={() => setView({ type: 'tab', tab: 'machines' })}
            />
          );
        }
        if (view.tab === 'machines') {
          return (
            <MachinesScreen
              machines={initialMachines}
              onMachineClick={(id) => setView({ type: 'machine-detail', machineId: id })}
              onNewChat={(machineId) => createNewChat(machineId)}
              onAddMachine={() => setView({ type: 'welcome' })}
            />
          );
        }
        if (view.tab === 'library') return <LibraryScreen />;
        if (view.tab === 'settings')
          return <SettingsScreen isDark={isDark} onToggleTheme={() => setIsDark(!isDark)} />;
        return null;
      }

      case 'machine-detail': {
        const machine = initialMachines.find((m) => m.id === view.machineId);
        if (!machine) return null;
        return (
          <MachineDetailScreen
            machine={machine}
            onBack={() => setView({ type: 'tab', tab: 'machines' })}
            onNewChat={() => createNewChat(machine.id)}
          />
        );
      }

      case 'chat': {
        const conv = conversations.find((c) => c.id === view.conversationId);
        const machine = initialMachines.find((m) => m.id === conv?.machineId);
        if (!conv || !machine) return null;
        return (
          <ChatScreen
            conversation={conv}
            machine={machine}
            onBack={() => setView({ type: 'tab', tab: 'chats' })}
            onUpdateConversation={updateConversation}
          />
        );
      }
    }
  };

  const showBottomNav =
    view.type === 'tab' && view.tab !== 'chat';

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-100 to-slate-200 dark:from-slate-950 dark:to-slate-900 flex items-center justify-center p-4 sm:p-8">
      {/* Theme toggle (outside phone) */}
      <button
        onClick={() => setIsDark(!isDark)}
        className="fixed top-4 right-4 z-50 w-10 h-10 rounded-full bg-white/80 dark:bg-white/10 backdrop-blur flex items-center justify-center shadow-lg hover:scale-110 transition-transform"
      >
        {isDark ? <Sun size={18} className="text-amber-400" /> : <Moon size={18} className="text-slate-700" />}
      </button>

      {/* Brand label (outside phone) */}
      <div className="fixed bottom-4 left-4 hidden sm:flex items-center gap-2 text-slate-400 dark:text-slate-600 text-xs">
        <Network size={14} />
        <span>LocalMesh AI — Design Prototype</span>
      </div>

      {/* Phone frame */}
      <div className="relative w-full max-w-[400px] h-[820px] max-h-[90vh] bg-black rounded-[44px] p-3 shadow-2xl shadow-slate-400/40 dark:shadow-black/60">
        {/* Screen */}
        <div className="relative w-full h-full bg-bg rounded-[34px] overflow-hidden flex flex-col">
          {/* Status bar */}
          <div className="flex items-center justify-between px-6 pt-3 pb-1 text-xs font-medium text-text-primary bg-bg">
            <span>9:41</span>
            <div className="flex items-center gap-1">
              <svg width="16" height="12" viewBox="0 0 16 12" fill="currentColor" className="text-text-primary">
                <path d="M1 8h2v4H1zM5 5h2v7H5zM9 2h2v10H9zM13 0h2v12h-2z" />
              </svg>
              <svg width="14" height="10" viewBox="0 0 14 10" fill="currentColor" className="text-text-primary">
                <path d="M7 9.5l1.5-1.5a2.12 2.12 0 0 0-3 0L7 9.5zM4 6.5l1-1a4.24 4.24 0 0 1 6 0l1 1a5.66 5.66 0 0 0-8 0zM1 3.5l1-1a8.49 8.49 0 0 1 12 0l1 1a9.9 9.9 0 0 0-14 0z" />
              </svg>
              <div className="flex items-center">
                <div className="w-6 h-3 rounded-sm border border-text-primary/60 relative">
                  <div className="absolute inset-0.5 rounded-sm bg-text-primary/80" />
                </div>
                <div className="w-0.5 h-1.5 rounded-r bg-text-primary/60" />
              </div>
            </div>
          </div>

          {/* Screen content */}
          <div className="flex-1 overflow-hidden relative">
            {renderScreen()}
          </div>

          {/* Bottom nav */}
          {showBottomNav && (
            <BottomNav
              active={view.type === 'tab' ? view.tab : 'chats'}
              onChange={(tab) => setView({ type: 'tab', tab })}
            />
          )}
        </div>
      </div>
    </div>
  );
}
