import { useRef, useEffect, useState } from 'react';
import {
  ArrowLeft,
  MoreVertical,
  Plus,
  Mic,
  Send,
  Square,
  Copy,
  RefreshCw,
  Brain,
  ChevronDown,
  ChevronRight,
  Camera,
  FileText,
  Image,

  ScanLine,
  X,
  Zap,
} from 'lucide-react';
import type {
  Conversation,
  ChatMessage,
  Machine,
} from '../types';
import { ConnectionChip } from '../ConnectionChip';
import { BottomSheet } from '../BottomSheet';
import { Markdown } from '../Markdown';
import { pathConfig } from '../icons';

interface Props {
  conversation: Conversation;
  machine: Machine;
  onBack: () => void;
  onUpdateConversation: (conv: Conversation) => void;
}

const sampleReplies: Record<string, string> = {
  default:
    "Here's what I can tell you:\n\nThis is a great question that touches on several important concepts. Let me break it down clearly.\n\n1. **The core idea** is straightforward once you see the pattern\n2. **The practical approach** involves a few key steps\n3. **The takeaway** is that you now have a framework to work with",
};

const attachTiles = [
  { icon: Camera, label: 'Camera', available: true },
  { icon: Image, label: 'Photos', available: true },
  { icon: FileText, label: 'Files', available: true },
  { icon: Mic, label: 'Voice note', available: true },
  { icon: ScanLine, label: 'Scan document', available: false },
  { icon: Zap, label: 'Task', available: false },
];

const suggestions = [
  'Summarise a document',
  'Describe a photo',
  'Explain some code',
  'Transcribe a voice note',
];

export function ChatScreen({ conversation, machine, onBack, onUpdateConversation }: Props) {
  const [input, setInput] = useState(conversation.draft);
  const [isStreaming, setIsStreaming] = useState(false);
  const [streamingContent, setStreamingContent] = useState('');
  const [showAttach, setShowAttach] = useState(false);
  const [showRouting, setShowRouting] = useState(false);
  const [showConnDetails, setShowConnDetails] = useState(false);
  const [expandedReasoning, setExpandedReasoning] = useState<string | null>(null);
  const [showSuggestions, setShowSuggestions] = useState(conversation.messages.length === 0);
  const scrollRef = useRef<HTMLDivElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const streamTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const messages = conversation.messages;
  const hasMessages = messages.length > 0;
  const config = pathConfig[conversation.path];

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length, streamingContent]);

  useEffect(() => {
    return () => {
      if (streamTimerRef.current) clearInterval(streamTimerRef.current);
    };
  }, []);

  const handleSend = () => {
    if (!input.trim() || isStreaming) return;
    if (machine.path === 'offline') return;

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      role: 'user',
      content: input.trim(),
      status: 'sent',
      timestamp: Date.now(),
    };

    const newMessages = [...conversation.messages, userMsg];
    onUpdateConversation({
      ...conversation,
      messages: newMessages,
      draft: '',
      lastActivity: Date.now(),
    });
    setInput('');
    setShowSuggestions(false);
    setIsStreaming(true);
    setStreamingContent('');

    const fullReply =
      sampleReplies[input.trim()] ||
      "Here's what I think:\n\n**Great question.** Let me walk through this step by step.\n\n1. First, consider the context of what you're asking\n2. Then, break the problem into smaller parts\n3. Finally, test each part and put it all together\n\nThis approach works for most problems like this one.";

    const tokens = fullReply.split(' ');
    let idx = 0;

    streamTimerRef.current = setInterval(() => {
      if (idx >= tokens.length) {
        if (streamTimerRef.current) clearInterval(streamTimerRef.current);
        streamTimerRef.current = null;

        const aiMsg: ChatMessage = {
          id: `msg-${Date.now()}-ai`,
          role: 'assistant',
          content: fullReply,
          machineName: machine.name,
          modelName: conversation.modelName,
          path: conversation.path,
          reasoningDuration: Math.floor(Math.random() * 5) + 2,
          status: 'complete',
          timestamp: Date.now(),
        };

        const updatedMessages = [...newMessages, aiMsg];
        onUpdateConversation({
          ...conversation,
          messages: updatedMessages,
          lastActivity: Date.now(),
        });
        setIsStreaming(false);
        setStreamingContent('');
        return;
      }

      const batch = tokens.slice(idx, idx + 2).join(' ');
      setStreamingContent((prev) => (prev ? prev + ' ' + batch : batch));
      idx += 2;
    }, 80);
  };

  const handleStop = () => {
    if (streamTimerRef.current) clearInterval(streamTimerRef.current);
    streamTimerRef.current = null;

    const partialContent = streamingContent.trim();
    if (partialContent) {
      const aiMsg: ChatMessage = {
        id: `msg-${Date.now()}-ai`,
        role: 'assistant',
        content: partialContent,
        machineName: machine.name,
        modelName: conversation.modelName,
        path: conversation.path,
        status: 'stopped',
        timestamp: Date.now(),
      };

      const updatedMessages = [...conversation.messages, aiMsg];
      onUpdateConversation({
        ...conversation,
        messages: updatedMessages,
        lastActivity: Date.now(),
      });
    }
    setIsStreaming(false);
    setStreamingContent('');
  };

  const isOffline = machine.path === 'offline';

  return (
    <div className="flex flex-col h-full bg-bg animate-slide-in-right">
      {/* App bar */}
      <div className="px-4 pt-4 pb-2 bg-bg-surface border-b border-outline">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="text-text-secondary p-1 -ml-1">
            <ArrowLeft size={22} />
          </button>
          <div className="flex-1 min-w-0">
            <h1 className="text-base font-semibold text-text-primary truncate">
              {conversation.title}
            </h1>
            <p className="text-xs text-text-secondary truncate">{machine.name}</p>
          </div>
          <button className="text-text-secondary p-1">
            <MoreVertical size={20} />
          </button>
        </div>

        {/* Route row */}
        <div className="flex items-center gap-2 mt-2">
          <ConnectionChip
            path={conversation.path}
            onClick={() => setShowConnDetails(true)}
          />
          <button
            onClick={() => setShowRouting(true)}
            className="inline-flex items-center gap-1 px-2 py-1 rounded-chip bg-bg-raised text-text-primary text-xs font-medium hover:brightness-95 dark:hover:brightness-110 transition-all"
          >
            {conversation.modelName}
            <ChevronDown size={12} />
          </button>
          {conversation.autoRouting && (
            <span className="inline-flex items-center gap-1 px-2 py-1 rounded-chip bg-[var(--tint-tunnel)] text-path-tunnel text-xs font-medium">
              <Zap size={10} /> Auto
            </span>
          )}
        </div>
      </div>

      {/* Messages */}
      <div
        ref={scrollRef}
        className="flex-1 overflow-y-auto scrollbar-thin px-4 py-4 space-y-4"
      >
        {!hasMessages && !isStreaming && showSuggestions && (
          <div className="flex flex-col items-center justify-center h-full text-center px-4">
            <div className="w-12 h-12 rounded-2xl bg-brand-container flex items-center justify-center mb-4">
              <Brain size={24} className="text-brand" />
            </div>
            <h2 className="text-lg font-semibold text-text-primary">
              {machine.name}
            </h2>
            <p className="text-sm text-text-secondary mt-1">
              {conversation.modelName}
            </p>
            <div className="mt-6 space-y-2 w-full max-w-[260px]">
              {suggestions
                .filter((s) =>
                  s === 'Describe a photo'
                    ? machine.capabilities.includes('vision')
                    : s === 'Transcribe a voice note'
                      ? machine.capabilities.includes('voice')
                      : s === 'Summarise a document'
                        ? machine.capabilities.includes('documents')
                        : true
                )
                .map((s) => (
                  <button
                    key={s}
                    onClick={() => setInput(s + ' ')}
                    className="w-full py-2.5 px-4 rounded-chip bg-bg-surface border border-outline text-sm text-text-primary text-left hover:border-brand/30 transition-colors"
                  >
                    {s}
                  </button>
                ))}
            </div>
          </div>
        )}

        {messages.map((msg) => (
          <MessageRow
            key={msg.id}
            msg={msg}
            onToggleReasoning={() =>
              setExpandedReasoning(
                expandedReasoning === msg.id ? null : msg.id
              )
            }
            expandedReasoning={expandedReasoning === msg.id}
          />
        ))}

        {isStreaming && (
          <div className="flex flex-col gap-1">
            {streamingContent ? (
              <div className="max-w-full">
                <Markdown content={streamingContent} />
                <span className="inline-block w-0.5 h-4 bg-brand animate-blink ml-0.5 align-middle" />
              </div>
            ) : (
              <div className="flex items-center gap-2 py-2">
                <div className="flex gap-1">
                  <div className="w-2 h-2 rounded-full bg-text-secondary animate-pulse-soft" />
                  <div
                    className="w-2 h-2 rounded-full bg-text-secondary animate-pulse-soft"
                    style={{ animationDelay: '0.2s' }}
                  />
                  <div
                    className="w-2 h-2 rounded-full bg-text-secondary animate-pulse-soft"
                    style={{ animationDelay: '0.4s' }}
                  />
                </div>
                <span className="text-xs text-text-secondary">
                  Loading {conversation.modelName} on {machine.name}…
                </span>
              </div>
            )}
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Composer */}
      <div className="px-3 py-3 bg-bg-surface border-t border-outline">
        <div className="flex items-end gap-2">
          <button
            onClick={() => setShowAttach(true)}
            disabled={isOffline}
            className="flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center text-text-secondary hover:bg-bg-raised disabled:opacity-40 transition-colors"
          >
            <Plus size={22} />
          </button>
          <div className="flex-1 bg-bg-raised rounded-[20px] px-4 py-2.5 min-h-[44px] max-h-[120px] overflow-y-auto scrollbar-none">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              rows={1}
              placeholder={
                isOffline
                  ? `${machine.name} is offline`
                  : `Message ${machine.name}`
              }
              disabled={isOffline}
              className="w-full bg-transparent text-[15px] text-text-primary placeholder:text-text-secondary outline-none resize-none disabled:cursor-not-allowed"
              style={{ minHeight: '20px' }}
            />
          </div>
          <button
            onClick={isStreaming ? handleStop : handleSend}
            disabled={!isStreaming && (!input.trim() || isOffline)}
            className={`flex-shrink-0 w-11 h-11 rounded-full flex items-center justify-center transition-all ${
              isStreaming
                ? 'bg-path-error text-white'
                : input.trim() && !isOffline
                  ? 'bg-brand text-white'
                  : 'bg-bg-raised text-text-secondary'
            } disabled:opacity-50`}
            style={
              isStreaming || (input.trim() && !isOffline)
                ? { color: 'white' }
                : {}
            }
          >
            {isStreaming ? (
              <Square size={18} fill="currentColor" />
            ) : input.trim() && !isOffline ? (
              <Send size={18} />
            ) : (
              <Mic size={20} />
            )}
          </button>
        </div>
      </div>

      {/* Attach sheet */}
      <BottomSheet
        open={showAttach}
        onClose={() => setShowAttach(false)}
        title="Attach"
      >
        <div className="grid grid-cols-3 gap-3">
          {attachTiles.map((tile) => {
            const Icon = tile.icon;
            return (
              <button
                key={tile.label}
                onClick={() => setShowAttach(false)}
                disabled={!tile.available}
                className={`flex flex-col items-center gap-2 p-4 rounded-card border ${
                  tile.available
                    ? 'border-outline bg-bg-surface hover:border-brand/30 text-text-primary'
                    : 'border-outline bg-bg-raised text-text-secondary opacity-60'
                } transition-colors`}
              >
                <Icon size={24} />
                <span className="text-xs font-medium">{tile.label}</span>
                {!tile.available && (
                  <span className="text-[10px] text-text-secondary text-center leading-tight">
                    Not available on this machine
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </BottomSheet>

      {/* Model and routing sheet */}
      <BottomSheet
        open={showRouting}
        onClose={() => setShowRouting(false)}
        title="Model and routing"
      >
        <div className="space-y-4">
          <div className="flex items-center justify-between p-3 rounded-chip bg-bg-raised">
            <div className="flex items-center gap-2">
              <Zap size={16} className="text-path-tunnel" />
              <span className="text-sm font-medium text-text-primary">Auto</span>
            </div>
            <span className="text-xs text-text-secondary">Choose automatically</span>
          </div>

          <div>
            <h3 className="text-xs font-medium text-text-secondary uppercase tracking-wide mb-2">
              {machine.name}
            </h3>
            <div className="space-y-1">
              {machine.models.map((model) => (
                <div
                  key={model.id}
                  className={`flex items-center justify-between p-3 rounded-chip border transition-colors ${
                    model.name === conversation.modelName
                      ? 'border-brand bg-brand-container'
                      : 'border-outline bg-bg-surface hover:border-brand/30'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <div
                      className={`w-3 h-3 rounded-full border-2 ${
                        model.name === conversation.modelName
                          ? 'border-brand bg-brand'
                          : 'border-outline'
                      }`}
                    />
                    <div>
                      <p className="text-sm font-medium text-text-primary">
                        {model.name}
                      </p>
                      <p className="text-xs text-text-secondary">
                        {model.loaded
                          ? `${model.tokPerSec} tok/s · fits in memory`
                          : `needs loading`}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </BottomSheet>

      {/* Connection details sheet */}
      <BottomSheet
        open={showConnDetails}
        onClose={() => setShowConnDetails(false)}
        title="Connection"
      >
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-text-primary">{machine.name}</span>
            <ConnectionChip path={conversation.path} />
          </div>
          <div className="bg-bg-raised rounded-chip p-3 space-y-1.5">
            <div className="flex justify-between">
              <span className="text-xs text-text-secondary">Address</span>
              <code className="text-xs font-mono text-text-primary">
                {machine.address}:{machine.port}
              </code>
            </div>
            <div className="flex justify-between">
              <span className="text-xs text-text-secondary">Latency</span>
              <span className="text-xs text-text-primary">
                {machine.path === 'offline' ? '—' : `${machine.latencyMs} ms`}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-xs text-text-secondary">Security</span>
              <span className="text-xs text-path-wifi font-medium">
                Encrypted on this network
              </span>
            </div>
          </div>

          <div>
            <h4 className="text-xs font-medium text-text-secondary uppercase tracking-wide mb-2">
              Connection attempts
            </h4>
            <div className="space-y-2">
              <AttemptRow label="Wi-Fi" result="Connected" success />
              <AttemptRow label="Secure tunnel" result="Not needed" />
              <AttemptRow label="Relay" result="Not needed" />
            </div>
          </div>

          <p className="text-xs text-text-secondary text-center">
            Your messages go straight to {machine.name}. LocalMesh servers never see them.
          </p>

          <button
            onClick={() => setShowConnDetails(false)}
            className="w-full h-11 rounded-full bg-brand-container text-brand font-medium text-sm hover:brightness-95 dark:hover:brightness-110 transition-all"
          >
            Reconnect
          </button>
        </div>
      </BottomSheet>
    </div>
  );
}

function AttemptRow({
  label,
  result,
  success,
}: {
  label: string;
  result: string;
  success?: boolean;
}) {
  return (
    <div className="flex items-center justify-between py-1">
      <span className="text-sm text-text-primary">{label}</span>
      <span
        className={`text-xs font-medium ${
          success ? 'text-path-wifi' : 'text-text-secondary'
        }`}
      >
        {result}
      </span>
    </div>
  );
}

function MessageRow({
  msg,
  onToggleReasoning,
  expandedReasoning,
}: {
  msg: ChatMessage;
  onToggleReasoning: () => void;
  expandedReasoning: boolean;
}) {
  if (msg.role === 'user') {
    return (
      <div className="flex justify-end animate-slide-in-right">
        <div className="max-w-[82%] bg-brand-container rounded-[18px] rounded-br-[4px] px-4 py-2.5">
          <p className="text-[15px] text-text-primary whitespace-pre-wrap">{msg.content}</p>
        </div>
      </div>
    );
  }

  const config = msg.path ? pathConfig[msg.path] : null;
  const isStopped = msg.status === 'stopped';

  return (
    <div className="flex flex-col gap-1 animate-fade-in">
      <div className="flex items-center gap-1.5">
        {config && (
          <div className={`w-1.5 h-1.5 rounded-full ${config.colorClass.replace('text-', 'bg-')}`} />
        )}
        <span className="text-xs text-text-secondary">
          {msg.modelName} · {msg.machineName}
        </span>
        {msg.routingNote && (
          <span className="text-xs text-text-secondary italic">
            · {msg.routingNote}
          </span>
        )}
      </div>

      {msg.reasoningDuration && (
        <button
          onClick={onToggleReasoning}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-chip border border-outline bg-bg-surface text-xs text-text-secondary w-fit hover:bg-bg-raised transition-colors"
        >
          {expandedReasoning ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
          <Brain size={12} />
          <span>
            {expandedReasoning
              ? 'Reasoning'
              : `Thought for ${msg.reasoningDuration} s`}
          </span>
        </button>
      )}

      {expandedReasoning && msg.reasoningDuration && (
        <div className="px-3 py-2.5 rounded-chip border border-outline bg-bg-raised text-xs text-text-secondary">
          I analyzed the request by breaking it into key components,
          considered the most relevant patterns, and structured the response
          for clarity.
        </div>
      )}

      <Markdown content={msg.content} />

      {isStopped && (
        <div className="flex items-center gap-2 mt-1">
          <span className="text-xs font-medium text-path-relay">Stopped</span>
          <button className="text-xs font-medium text-brand hover:underline">
            Continue
          </button>
          <button className="text-xs font-medium text-text-secondary hover:underline">
            Regenerate
          </button>
        </div>
      )}

      {msg.status === 'complete' && (
        <div className="flex items-center gap-3 mt-1.5">
          <button className="text-xs text-text-secondary flex items-center gap-1 hover:text-text-primary transition-colors">
            <Copy size={12} /> Copy
          </button>
          <button className="text-xs text-text-secondary flex items-center gap-1 hover:text-text-primary transition-colors">
            <RefreshCw size={12} /> Regenerate
          </button>
        </div>
      )}
    </div>
  );
}
