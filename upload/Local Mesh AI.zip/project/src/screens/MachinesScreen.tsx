import { Plus, MoreVertical, Star, ArrowLeft } from 'lucide-react';
import type { Machine } from '../types';
import { ConnectionChip } from '../ConnectionChip';
import { pathConfig } from '../icons';

interface Props {
  machines: Machine[];
  onMachineClick: (id: string) => void;
  onNewChat: (machineId: string) => void;
  onAddMachine: () => void;
}

const capLabels: Record<string, string> = {
  chat: 'Chat',
  vision: 'Vision',
  voice: 'Voice',
  documents: 'Documents',
  ocr: 'OCR',
  agent: 'Agent',
};

export function MachinesScreen({ machines, onMachineClick, onNewChat, onAddMachine }: Props) {
  const onlineCount = machines.filter((m) => m.path !== 'offline').length;

  return (
    <div className="flex flex-col h-full bg-bg animate-fade-in">
      <div className="px-5 pt-5 pb-3">
        <h1 className="text-[22px] font-semibold text-text-primary">My AI machines</h1>
        <p className="text-sm text-text-secondary mt-0.5">
          {onlineCount} of {machines.length} online
        </p>
      </div>

      <div className="flex-1 overflow-y-auto scrollbar-thin px-4 pb-4 space-y-3">
        {machines.map((machine) => {
          const config = pathConfig[machine.path];
          const isOffline = machine.path === 'offline';
          const currentModel = machine.models.find((m) => m.loaded);

          return (
            <div
              key={machine.id}
              onClick={() => onMachineClick(machine.id)}
              className={`bg-bg-surface rounded-card border border-outline p-4 cursor-pointer hover:border-brand/30 transition-colors ${
                isOffline ? 'opacity-[0.78]' : ''
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2">
                  <config.icon
                    size={18}
                    className={config.colorClass}
                    strokeWidth={2}
                  />
                  <h2 className="text-base font-semibold text-text-primary">
                    {machine.name}
                  </h2>
                  {machine.preferred && (
                    <Star size={14} className="text-brand fill-brand" />
                  )}
                </div>
                <button
                  onClick={(e) => e.stopPropagation()}
                  className="text-text-secondary p-1 -mr-1"
                >
                  <MoreVertical size={18} />
                </button>
              </div>

              <div className="mt-2 flex items-center gap-2 flex-wrap">
                <ConnectionChip path={machine.path} />
                <span className="text-xs text-text-secondary">
                  {machine.hardware}
                </span>
              </div>

              <div className="mt-2">
                <span className="text-sm text-text-primary">
                  {currentModel
                    ? currentModel.name
                    : machine.models[0]?.name || 'No model loaded'}
                </span>
                {currentModel && currentModel.tokPerSec > 0 && (
                  <span className="text-xs text-text-secondary ml-2">
                    · {currentModel.tokPerSec} tok/s
                  </span>
                )}
                {isOffline && machine.lastSeen && (
                  <span className="text-xs text-text-secondary ml-2">
                    · Last seen {machine.lastSeen}
                  </span>
                )}
              </div>

              <div className="mt-3 flex items-center gap-1.5 flex-wrap">
                {machine.capabilities.map((cap) => (
                  <span
                    key={cap}
                    className="text-[11px] font-medium px-2 py-0.5 rounded-chip bg-bg-raised text-text-secondary"
                  >
                    {capLabels[cap] || cap}
                  </span>
                ))}
              </div>

              <div className="mt-3 flex items-center gap-3">
                {!isOffline && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onNewChat(machine.id);
                    }}
                    className="text-sm font-medium text-brand h-9 px-3 rounded-full bg-brand-container hover:brightness-95 dark:hover:brightness-110 transition-all"
                  >
                    New chat
                  </button>
                )}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onMachineClick(machine.id);
                  }}
                  className="text-sm font-medium text-text-secondary h-9 px-3 hover:text-text-primary transition-colors"
                >
                  Details
                </button>
              </div>
            </div>
          );
        })}

        <button
          onClick={onAddMachine}
          className="w-full bg-bg-surface rounded-card border-2 border-dashed border-outline p-4 flex items-center justify-center gap-2 text-text-secondary hover:text-brand hover:border-brand/30 transition-colors mt-2"
        >
          <Plus size={18} />
          <span className="text-sm font-medium">Add machine</span>
        </button>
      </div>
    </div>
  );
}

interface DetailProps {
  machine: Machine;
  onBack: () => void;
  onNewChat: () => void;
}

export function MachineDetailScreen({ machine, onBack, onNewChat }: DetailProps) {
  const config = pathConfig[machine.path];
  const vramPct = machine.vram.total > 0 ? (machine.vram.used / machine.vram.total) * 100 : 0;
  const memPct = machine.memory.total > 0 ? (machine.memory.used / machine.memory.total) * 100 : 0;

  return (
    <div className="flex flex-col h-full bg-bg animate-slide-in-right">
      <div className="flex items-center gap-3 px-4 pt-5 pb-3">
        <button onClick={onBack} className="text-text-secondary p-1">
          <ArrowLeft size={22} />
        </button>
        <div className="flex-1">
          <h1 className="text-[22px] font-semibold text-text-primary">{machine.name}</h1>
        </div>
        {machine.preferred && (
          <span className="flex items-center gap-1 text-xs font-medium text-brand bg-brand-container px-2 py-1 rounded-chip">
            <Star size={12} className="fill-brand" /> Preferred
          </span>
        )}
      </div>

      <div className="px-5 pb-3 flex items-center gap-2">
        <ConnectionChip path={machine.path} />
        {machine.path !== 'offline' && (
          <span className="text-xs text-text-secondary">· {machine.latencyMs} ms</span>
        )}
      </div>

      <div className="flex-1 overflow-y-auto scrollbar-thin px-4 pb-4 space-y-4">
        {machine.vram.total > 0 && (
          <div className="bg-bg-surface rounded-card border border-outline p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-text-primary">Hardware</h3>
              {machine.tempC && (
                <span className="text-xs text-text-secondary">{machine.tempC}°C</span>
              )}
            </div>
            <p className="text-sm text-text-primary mb-3">{machine.hardware}</p>
            <div className="space-y-3">
              <Meter label="VRAM" used={machine.vram.used} total={machine.vram.total} pct={vramPct} />
              <Meter label="Memory" used={machine.memory.used} total={machine.memory.total} pct={memPct} />
            </div>
          </div>
        )}

        <div className="bg-bg-surface rounded-card border border-outline p-4">
          <h3 className="text-sm font-semibold text-text-primary mb-3">Models</h3>
          <div className="space-y-2">
            {machine.models.map((model) => (
              <div
                key={model.id}
                className="flex items-start justify-between py-2"
              >
                <div className="flex items-start gap-2.5">
                  <div
                    className={`w-2 h-2 rounded-full mt-1.5 ${
                      model.loaded ? 'bg-path-wifi' : 'bg-outline'
                    }`}
                  />
                  <div>
                    <p className="text-sm font-medium text-text-primary">{model.name}</p>
                    <p className="text-xs text-text-secondary">
                      {model.quant} · {model.context} · {model.loaded ? 'loaded' : 'on disk'}
                    </p>
                  </div>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <span className="text-[11px] font-medium px-2 py-0.5 rounded-chip bg-bg-raised text-text-secondary">
                    {model.capability}
                  </span>
                  {model.tokPerSec > 0 && (
                    <span className="text-xs text-text-secondary">{model.tokPerSec} tok/s</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-bg-surface rounded-card border border-outline p-4">
          <h3 className="text-sm font-semibold text-text-primary mb-3">Services</h3>
          <div className="flex items-center gap-1.5 flex-wrap">
            {machine.capabilities.map((cap) => (
              <span
                key={cap}
                className="text-[11px] font-medium px-2 py-1 rounded-chip bg-bg-raised text-text-primary"
              >
                {capLabels[cap]}
              </span>
            ))}
            {!machine.capabilities.includes('agent') && (
              <span className="text-[11px] font-medium px-2 py-1 rounded-chip bg-bg-raised text-text-secondary">
                Agent · not set up
              </span>
            )}
          </div>
        </div>
      </div>

      {machine.path !== 'offline' && (
        <div className="px-5 py-3 bg-bg-surface border-t border-outline">
          <button
            onClick={onNewChat}
            className="w-full h-11 rounded-full bg-brand text-white font-medium text-[15px] active:scale-[0.98] transition-transform"
            style={{ color: 'white' }}
          >
            Start chat
          </button>
        </div>
      )}
    </div>
  );
}

function Meter({ label, used, total, pct }: { label: string; used: number; total: number; pct: number }) {
  const color = pct > 85 ? 'bg-path-relay' : 'bg-brand';
  return (
    <div>
      <div className="flex items-center justify-between mb-1.5">
        <span className="text-xs font-medium text-text-primary">{label}</span>
        <span className="text-xs text-text-secondary">
          {used} of {total} GB
        </span>
      </div>
      <div className="h-1.5 rounded-full bg-bg-raised overflow-hidden">
        <div
          className={`h-full rounded-full ${color} transition-all`}
          style={{ width: `${Math.min(pct, 100)}%` }}
        />
      </div>
    </div>
  );
}
