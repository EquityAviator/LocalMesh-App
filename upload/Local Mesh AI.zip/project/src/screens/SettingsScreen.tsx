import { ChevronRight, Sun, Moon, Monitor, Smartphone, Shield, Wifi, Palette } from 'lucide-react';

interface Props {
  isDark: boolean;
  onToggleTheme: () => void;
}

const sections = [
  {
    icon: Shield,
    title: 'Connection',
    summary: 'Path order, trusted networks',
  },
  {
    icon: Smartphone,
    title: 'Devices and security',
    summary: '2 phones, 3 machines · App lock',
  },
  {
    icon: Palette,
    title: 'Models and routing',
    summary: 'Auto routing on',
  },
  {
    icon: Monitor,
    title: 'Chat',
    summary: 'Text size, Enter key, markdown',
  },
  {
    icon: Wifi,
    title: 'Notifications',
    summary: 'Replies, machines, approvals',
  },
  {
    icon: Shield,
    title: 'Storage and history',
    summary: 'Export, auto-delete, clear',
  },
  {
    icon: Palette,
    title: 'Appearance',
    summary: 'Theme, dynamic colour',
  },
  {
    icon: Monitor,
    title: 'About and diagnostics',
    summary: 'Version, share logs without chats',
  },
];

export function SettingsScreen({ isDark, onToggleTheme }: Props) {
  return (
    <div className="flex flex-col h-full bg-bg animate-fade-in">
      <div className="px-5 pt-5 pb-3">
        <h1 className="text-[22px] font-semibold text-text-primary">Settings</h1>
      </div>

      <div className="flex-1 overflow-y-auto scrollbar-thin px-4 pb-4 space-y-3">
        {/* Account card */}
        <div className="bg-bg-surface rounded-card border border-outline p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-brand-container flex items-center justify-center">
              <span className="text-sm font-semibold text-brand">A</span>
            </div>
            <div className="flex-1">
              <p className="text-sm font-semibold text-text-primary">Signed in with Google</p>
              <p className="text-xs text-text-secondary">you@example.com</p>
            </div>
          </div>
        </div>

        {/* Theme toggle */}
        <div className="bg-bg-surface rounded-card border border-outline p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              {isDark ? <Moon size={20} className="text-text-secondary" /> : <Sun size={20} className="text-text-secondary" />}
              <div>
                <p className="text-sm font-medium text-text-primary">Appearance</p>
                <p className="text-xs text-text-secondary">{isDark ? 'Dark' : 'Light'} theme</p>
              </div>
            </div>
            <button
              onClick={onToggleTheme}
              className={`w-12 h-7 rounded-full transition-colors relative ${
                isDark ? 'bg-brand' : 'bg-bg-raised'
              }`}
            >
              <div
                className={`absolute top-0.5 w-6 h-6 rounded-full bg-white transition-all ${
                  isDark ? 'left-[22px]' : 'left-0.5'
                }`}
              />
            </button>
          </div>
        </div>

        {/* Settings sections */}
        {sections.slice(1).map((section) => {
          const Icon = section.icon;
          return (
            <button
              key={section.title}
              className="w-full bg-bg-surface rounded-card border border-outline p-4 flex items-center gap-3 hover:border-brand/30 transition-colors text-left"
            >
              <Icon size={20} className="text-text-secondary flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-text-primary">{section.title}</p>
                <p className="text-xs text-text-secondary truncate">{section.summary}</p>
              </div>
              <ChevronRight size={18} className="text-text-secondary flex-shrink-0" />
            </button>
          );
        })}
      </div>
    </div>
  );
}
