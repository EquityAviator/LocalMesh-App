import { Search, MessageSquare, Plus } from 'lucide-react';
import type { Conversation } from '../types';
import { pathConfig } from '../icons';

interface Props {
  conversations: Conversation[];
  onOpenChat: (id: string) => void;
  onNewChat: () => void;
}

function relativeTime(ts: number) {
  const diff = Date.now() - ts;
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'now';
  if (mins < 60) return `${mins}m`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h`;
  const days = Math.floor(hours / 24);
  return `${days}d`;
}

export function ChatsScreen({ conversations, onOpenChat, onNewChat }: Props) {
  return (
    <div className="flex flex-col h-full bg-bg animate-fade-in">
      <div className="px-5 pt-5 pb-3">
        <div className="flex items-center justify-between">
          <h1 className="text-[22px] font-semibold text-text-primary">Chats</h1>
          <button
            onClick={onNewChat}
            className="w-9 h-9 rounded-full bg-brand-container flex items-center justify-center text-brand"
          >
            <Plus size={20} />
          </button>
        </div>
        <div className="mt-3 relative">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-text-secondary" />
          <input
            placeholder="Search chats"
            className="w-full h-10 pl-9 pr-4 rounded-full bg-bg-raised text-sm text-text-primary placeholder:text-text-secondary outline-none border border-transparent focus:border-brand/30 transition-colors"
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto scrollbar-thin px-3 pb-3">
        {conversations.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center px-6">
            <div className="w-14 h-14 rounded-2xl bg-bg-raised flex items-center justify-center mb-4">
              <MessageSquare size={28} className="text-text-secondary" />
            </div>
            <h2 className="text-base font-semibold text-text-primary">No chats yet</h2>
            <p className="text-sm text-text-secondary mt-1">
              Start a conversation with one of your machines.
            </p>
            <button
              onClick={onNewChat}
              className="mt-4 h-10 px-5 rounded-full bg-brand text-white font-medium text-sm"
              style={{ color: 'white' }}
            >
              New chat
            </button>
          </div>
        ) : (
          conversations.map((conv) => {
            const config = pathConfig[conv.path];
            const lastMsg = conv.messages[conv.messages.length - 1];
            return (
              <button
                key={conv.id}
                onClick={() => onOpenChat(conv.id)}
                className="w-full flex items-start gap-3 px-3 py-3 rounded-card hover:bg-bg-surface transition-colors text-left"
              >
                <div className={`w-2 h-2 rounded-full mt-2 flex-shrink-0 ${config.colorClass.replace('text-', 'bg-')}`} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <h2 className="text-[15px] font-semibold text-text-primary truncate">
                      {conv.title}
                    </h2>
                    <span className="text-xs text-text-secondary flex-shrink-0 ml-2">
                      {relativeTime(conv.lastActivity)}
                    </span>
                  </div>
                  <p className="text-sm text-text-secondary truncate mt-0.5">
                    {lastMsg?.content || 'No messages yet'}
                  </p>
                  <p className="text-xs text-text-secondary mt-1">
                    {conv.machineName} · {conv.modelName}
                  </p>
                </div>
              </button>
            );
          })
        )}
      </div>
    </div>
  );
}
