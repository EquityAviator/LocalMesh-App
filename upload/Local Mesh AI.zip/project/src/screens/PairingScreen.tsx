import { useState } from 'react';
import { ArrowLeft, Check, X, QrCode, Shield } from 'lucide-react';

interface Props {
  onBack: () => void;
  onComplete: () => void;
}

export function PairingScreen({ onBack, onComplete }: Props) {
  const [step, setStep] = useState(1);
  const [codeMatch, setCodeMatch] = useState<boolean | null>(null);

  return (
    <div className="flex flex-col h-full bg-bg animate-slide-in-right">
      <div className="flex items-center gap-3 px-4 pt-5 pb-3">
        <button onClick={onBack} className="text-text-secondary p-1">
          <ArrowLeft size={22} />
        </button>
        <div className="flex-1">
          <h1 className="text-base font-semibold text-text-primary">Pair a machine</h1>
          <p className="text-xs text-text-secondary">Step {step} of 4</p>
        </div>
        <div className="w-24 h-1 rounded-full bg-bg-raised overflow-hidden">
          <div
            className="h-full bg-brand transition-all"
            style={{ width: `${(step / 4) * 100}%` }}
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto scrollbar-thin px-5 py-4">
        {step === 1 && (
          <div className="flex flex-col items-center text-center pt-8">
            <div className="w-16 h-16 rounded-2xl bg-brand-container flex items-center justify-center mb-6">
              <Shield size={32} className="text-brand" />
            </div>
            <h2 className="text-lg font-semibold text-text-primary mb-2">
              Sign in with Google
            </h2>
            <p className="text-sm text-text-secondary max-w-[260px] leading-relaxed mb-8">
              Google only confirms it's you. Your chats never go through Google or LocalMesh servers.
            </p>
            <button
              onClick={() => setStep(2)}
              className="w-full max-w-[280px] h-12 rounded-full bg-brand text-white font-medium text-[15px]"
              style={{ color: 'white' }}
            >
              Continue with Google
            </button>
          </div>
        )}

        {step === 2 && (
          <div className="flex flex-col items-center text-center pt-6">
            <div className="w-48 h-48 rounded-3xl bg-bg-surface border-2 border-outline flex items-center justify-center mb-6 relative">
              <QrCode size={120} className="text-text-primary" strokeWidth={1.2} />
              <div className="absolute inset-0 rounded-3xl border-2 border-brand/20" />
            </div>
            <h2 className="text-lg font-semibold text-text-primary mb-2">
              Scan the QR code on your PC
            </h2>
            <p className="text-sm text-text-secondary max-w-[260px] mb-6">
              Open LocalMesh on your PC and choose Add device.
            </p>
            <button className="text-sm font-medium text-brand mb-6">
              Enter code instead
            </button>
            <button
              onClick={() => setStep(3)}
              className="w-full max-w-[280px] h-12 rounded-full bg-brand text-white font-medium text-[15px]"
              style={{ color: 'white' }}
            >
              Continue
            </button>
          </div>
        )}

        {step === 3 && (
          <div className="flex flex-col items-center text-center pt-8">
            <h2 className="text-lg font-semibold text-text-primary mb-2">
              Check the code
            </h2>
            <p className="text-sm text-text-secondary max-w-[240px] mb-8">
              Your PC should show the same six digits.
            </p>
            <div className="text-[40px] font-bold tracking-[0.15em] text-text-primary mb-3">
              482 917
            </div>
            <p className="text-xs text-text-secondary mb-8">Expires in 0:52</p>
            <div className="w-full max-w-[280px] space-y-3">
              <button
                onClick={() => {
                  setCodeMatch(true);
                  setStep(4);
                }}
                className="w-full h-12 rounded-full bg-brand text-white font-medium text-[15px] flex items-center justify-center gap-2"
                style={{ color: 'white' }}
              >
                <Check size={18} /> They match
              </button>
              <button
                onClick={() => setCodeMatch(false)}
                className="w-full h-12 rounded-full bg-bg-surface border border-outline text-text-primary font-medium text-[15px] flex items-center justify-center gap-2"
              >
                <X size={18} /> They don't match
              </button>
            </div>
            {codeMatch === false && (
              <p className="text-sm text-path-error mt-4 max-w-[260px]">
                Start again on your PC to get a new code.
              </p>
            )}
          </div>
        )}

        {step === 4 && (
          <div className="pt-4">
            <h2 className="text-lg font-semibold text-text-primary mb-1">
              Connect from anywhere
            </h2>
            <p className="text-sm text-text-secondary mb-5">
              Three quick checks so Gaming PC works away from home.
            </p>
            <div className="space-y-3">
              <CheckRow icon={Shield} title="Signed in" detail="Identity only. Chats never go through Google." done />
              <CheckRow icon={QrCode} title="Gaming PC is paired" detail='Named "Gaming PC"' done />
              <CheckRow icon={Shield} title="Secure tunnel app" detail="Not installed on this phone" action="Install" />
            </div>
            <div className="mt-6 space-y-3">
              <button
                onClick={onComplete}
                className="w-full h-12 rounded-full bg-brand text-white font-medium text-[15px]"
                style={{ color: 'white' }}
              >
                Test remote connection
              </button>
              <button
                onClick={onComplete}
                className="w-full h-12 rounded-full bg-bg-surface border border-outline text-text-primary font-medium text-[15px]"
              >
                Use on home Wi-Fi only
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function CheckRow({
  icon: Icon,
  title,
  detail,
  done,
  action,
}: {
  icon: typeof Shield;
  title: string;
  detail: string;
  done?: boolean;
  action?: string;
}) {
  return (
    <div className="bg-bg-surface rounded-card border border-outline p-3.5 flex items-center gap-3">
      <div
        className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
          done ? 'bg-[var(--tint-wifi)]' : 'bg-bg-raised'
        }`}
      >
        {done ? (
          <Check size={16} className="text-path-wifi" />
        ) : (
          <Icon size={16} className="text-text-secondary" />
        )}
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-text-primary">{title}</p>
        <p className="text-xs text-text-secondary truncate">{detail}</p>
      </div>
      {action && (
        <button className="text-xs font-medium text-brand px-3 py-1.5 rounded-full bg-brand-container">
          {action}
        </button>
      )}
    </div>
  );
}
