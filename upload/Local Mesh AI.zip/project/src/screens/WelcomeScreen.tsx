import { Network, Sparkles } from 'lucide-react';

interface Props {
  onFindLocal: () => void;
  onConnectRemote: () => void;
  onShowFound: () => void;
  scanning: boolean;
}

export function WelcomeScreen({ onFindLocal, onConnectRemote, onShowFound, scanning }: Props) {
  return (
    <div className="flex flex-col h-full bg-bg animate-fade-in">
      <div className="flex-1 flex flex-col items-center justify-center px-6">
        <div className="relative mb-8">
          <div className="w-20 h-20 rounded-3xl bg-brand-container flex items-center justify-center">
            <Network size={36} className="text-brand" strokeWidth={2.2} />
          </div>
        </div>
        <h1 className="text-[26px] font-semibold text-text-primary text-center leading-tight max-w-[260px]">
          Chat with AI that runs on your own PC
        </h1>
        <p className="text-text-secondary text-[15px] text-center mt-3 max-w-[260px] leading-relaxed">
          Private by design. Your chats stay on your devices.
        </p>

        <div className="flex items-center gap-2 mt-6 px-3 py-1.5 rounded-full bg-brand-container">
          <Sparkles size={14} className="text-brand" />
          <span className="text-xs font-medium text-brand">LocalMesh AI</span>
        </div>
      </div>

      <div className="px-5 pb-8 space-y-3">
        <button
          onClick={onShowFound}
          className="w-full h-12 rounded-full bg-brand text-white font-medium text-[15px] flex items-center justify-center gap-2 active:scale-[0.98] transition-transform"
          style={{ color: 'white' }}
        >
          {scanning ? 'Looking for machines nearby…' : 'Find my PC on this Wi-Fi'}
        </button>
        <button
          onClick={onConnectRemote}
          className="w-full h-12 rounded-full bg-bg-surface border border-outline text-text-primary font-medium text-[15px] flex items-center justify-center active:scale-[0.98] transition-transform"
        >
          Connect from anywhere
        </button>
        {scanning && (
          <div className="flex items-center justify-center gap-2 pt-1">
            <div className="w-4 h-4 border-2 border-brand border-t-transparent rounded-full animate-spin" />
            <span className="text-xs text-text-secondary">Scanning local network…</span>
          </div>
        )}
      </div>
    </div>
  );
}
