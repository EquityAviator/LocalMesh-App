import { FileText, Image, Mic, Plus, Library as LibIcon } from 'lucide-react';

const tabs = ['Documents', 'Images', 'Voice notes'] as const;

export function LibraryScreen() {
  return (
    <div className="flex flex-col h-full bg-bg animate-fade-in">
      <div className="px-5 pt-5 pb-3">
        <h1 className="text-[22px] font-semibold text-text-primary">Library</h1>
      </div>

      <div className="px-5 flex items-center gap-2 mb-3">
        {tabs.map((tab, i) => (
          <button
            key={tab}
            className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
              i === 0
                ? 'bg-brand-container text-brand'
                : 'bg-bg-raised text-text-secondary'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto scrollbar-thin px-4 pb-4">
        <div className="flex flex-col items-center justify-center h-full text-center">
          <div className="w-14 h-14 rounded-2xl bg-bg-raised flex items-center justify-center mb-4">
            <LibIcon size={28} className="text-text-secondary" />
          </div>
          <h2 className="text-base font-semibold text-text-primary">Nothing here yet</h2>
          <p className="text-sm text-text-secondary mt-1 max-w-[220px]">
            Add a document to ask questions about it on your PC.
          </p>
          <button className="mt-4 h-10 px-5 rounded-full bg-brand text-white font-medium text-sm flex items-center gap-2" style={{ color: 'white' }}>
            <Plus size={16} /> Add document
          </button>
        </div>
      </div>
    </div>
  );
}
