import { pathConfig } from './icons';
import type { ConnectionPath, ConnectionState } from './types';

interface Props {
  path: ConnectionPath;
  state?: ConnectionState;
  size?: 'sm' | 'md';
  showLabel?: boolean;
  onClick?: () => void;
}

export function ConnectionChip({
  path,
  state = 'connected',
  size = 'sm',
  showLabel = true,
  onClick,
}: Props) {
  const config = pathConfig[path];
  const Icon = config.icon;
  const isConnecting = state === 'connecting';
  const isNeedsAttention = state === 'needs-attention';

  const label = isConnecting
    ? 'Connecting'
    : isNeedsAttention
      ? 'Sign in again'
      : config.label;

  const colorClass = isNeedsAttention ? 'text-path-error' : config.colorClass;
  const tintClass = isNeedsAttention
    ? 'bg-[var(--tint-error)]'
    : config.tintClass;

  const padX = size === 'sm' ? 'px-2' : 'px-2.5';
  const padY = size === 'sm' ? 'py-1' : 'py-1.5';
  const iconSize = size === 'sm' ? 12 : 14;
  const textSize = size === 'sm' ? 'text-xs' : 'text-sm';

  return (
    <button
      onClick={onClick}
      disabled={!onClick}
      className={`inline-flex items-center gap-1.5 rounded-chip ${padX} ${padY} ${tintClass} ${colorClass} ${onClick ? 'cursor-pointer hover:brightness-95 dark:hover:brightness-110' : 'cursor-default'} transition-all`}
    >
      <Icon size={iconSize} strokeWidth={2} className={isConnecting ? 'animate-pulse-soft' : ''} />
      {showLabel && <span className={`font-medium ${textSize}`}>{label}</span>}
    </button>
  );
}
