import {
  Wifi,
  Shield,
  Cloud,
  WifiOff,
  type LucideIcon,
} from 'lucide-react';
import type { ConnectionPath } from './types';

export const pathConfig: Record<
  ConnectionPath,
  { label: string; icon: LucideIcon; colorClass: string; tintClass: string }
> = {
  wifi: {
    label: 'Wi-Fi',
    icon: Wifi,
    colorClass: 'text-path-wifi',
    tintClass: 'bg-[var(--tint-wifi)]',
  },
  tunnel: {
    label: 'Secure tunnel',
    icon: Shield,
    colorClass: 'text-path-tunnel',
    tintClass: 'bg-[var(--tint-tunnel)]',
  },
  relay: {
    label: 'Relay',
    icon: Cloud,
    colorClass: 'text-path-relay',
    tintClass: 'bg-[var(--tint-relay)]',
  },
  offline: {
    label: 'Offline',
    icon: WifiOff,
    colorClass: 'text-path-offline',
    tintClass: 'bg-[var(--tint-offline)]',
  },
};
