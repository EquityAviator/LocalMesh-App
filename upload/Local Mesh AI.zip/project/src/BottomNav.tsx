import { MessageSquare, Monitor, Library, Settings } from 'lucide-react';
import type { ScreenTab } from './types';

interface Props {
  active: ScreenTab;
  onChange: (tab: ScreenTab) => void;
}

const tabs: { id: ScreenTab; label: string; icon: typeof MessageSquare }[] = [
  { id: 'chats', label: 'Chats', icon: MessageSquare },
  { id: 'machines', label: 'Machines', icon: Monitor },
  { id: 'library', label: 'Library', icon: Library },
  { id: 'settings', label: 'Settings', icon: Settings },
];

export function BottomNav({ active, onChange }: Props) {
  return (
    <div className="flex items-center justify-around bg-bg-surface border-t border-outline px-2 py-2 h-[60px]">
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = active === tab.id;
        return (
          <button
            key={tab.id}
            onClick={() => onChange(tab.id)}
            className="flex flex-col items-center justify-center gap-1 w-16 h-12 rounded-xl transition-colors"
          >
            <Icon
              size={22}
              strokeWidth={isActive ? 2.5 : 2}
              className={isActive ? 'text-brand' : 'text-text-secondary'}
            />
            <span
              className={`text-[11px] font-medium ${
                isActive ? 'text-brand' : 'text-text-secondary'
              }`}
            >
              {tab.label}
            </span>
          </button>
        );
      })}
    </div>
  );
}
