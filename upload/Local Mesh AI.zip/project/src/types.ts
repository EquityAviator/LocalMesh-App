export type ConnectionPath = 'wifi' | 'tunnel' | 'relay' | 'offline';
export type ConnectionState = 'connected' | 'connecting' | 'needs-attention';

export type Capability = 'chat' | 'vision' | 'voice' | 'documents' | 'ocr' | 'agent';

export interface Model {
  id: string;
  name: string;
  quant: string;
  context: string;
  loaded: boolean;
  tokPerSec: number;
  capability: string;
  fitNote: 'fits' | 'needs-loading' | 'too-large';
}

export interface Machine {
  id: string;
  name: string;
  backend: string;
  address: string;
  port: string;
  path: ConnectionPath;
  connectionState: ConnectionState;
  latencyMs: number;
  preferred: boolean;
  hardware: string;
  vram: { used: number; total: number };
  memory: { used: number; total: number };
  tempC: number | null;
  models: Model[];
  capabilities: Capability[];
  lastSeen: string | null;
  token?: string;
}

export interface Attachment {
  id: string;
  type: 'image' | 'file';
  name: string;
  size: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  machineName?: string;
  modelName?: string;
  path?: ConnectionPath;
  routingNote?: string;
  reasoning?: string;
  reasoningDuration?: number;
  status: 'sending' | 'sent' | 'streaming' | 'complete' | 'stopped' | 'interrupted' | 'failed';
  attachments?: Attachment[];
  timestamp: number;
}

export interface Conversation {
  id: string;
  title: string;
  machineId: string;
  machineName: string;
  modelName: string;
  path: ConnectionPath;
  autoRouting: boolean;
  messages: ChatMessage[];
  draft: string;
  lastActivity: number;
}

export type ScreenTab = 'chats' | 'machines' | 'library' | 'settings';
export type ScreenView =
  | { type: 'welcome' }
  | { type: 'pairing' }
  | { type: 'tab'; tab: ScreenTab }
  | { type: 'machine-detail'; machineId: string }
  | { type: 'chat'; conversationId: string };
