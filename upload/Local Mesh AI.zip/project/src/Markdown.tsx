interface Props {
  content: string;
}

function escapeHtml(s: string) {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function renderInline(text: string) {
  let s = escapeHtml(text);
  s = s.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  s = s.replace(/`(.+?)`/g, '<code>$1</code>');
  return s;
}

export function Markdown({ content }: Props) {
  const lines = content.split('\n');
  const blocks: string[] = [];
  let listBuffer: string[] = [];
  let ordered = false;

  const flushList = () => {
    if (listBuffer.length) {
      const tag = ordered ? 'ol' : 'ul';
      blocks.push(`<${tag}>${listBuffer.join('')}</${tag}>`);
      listBuffer = [];
      ordered = false;
    }
  };

  for (const line of lines) {
    const trimmed = line.trimEnd();

    if (trimmed === '') {
      flushList();
      continue;
    }

    const olMatch = trimmed.match(/^(\d+)\.\s+(.*)/);
    const ulMatch = trimmed.match(/^[-*]\s+(.*)/);

    if (olMatch) {
      if (!ordered && listBuffer.length) flushList();
      ordered = true;
      listBuffer.push(`<li>${renderInline(olMatch[2])}</li>`);
      continue;
    }
    if (ulMatch) {
      if (ordered && listBuffer.length) flushList();
      ordered = false;
      listBuffer.push(`<li>${renderInline(ulMatch[1])}</li>`);
      continue;
    }

    flushList();
    blocks.push(`<p>${renderInline(trimmed)}</p>`);
  }
  flushList();

  return (
    <div
      className="prose-chat text-text-primary text-[15px] leading-[1.5]"
      dangerouslySetInnerHTML={{ __html: blocks.join('') }}
    />
  );
}
