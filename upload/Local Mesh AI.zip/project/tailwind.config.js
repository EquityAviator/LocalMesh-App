/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        bg: {
          DEFAULT: 'var(--color-bg)',
          surface: 'var(--color-surface)',
          raised: 'var(--color-raised)',
        },
        outline: {
          DEFAULT: 'var(--color-outline)',
        },
        text: {
          primary: 'var(--color-text-primary)',
          secondary: 'var(--color-text-secondary)',
        },
        brand: {
          DEFAULT: 'var(--color-brand)',
          container: 'var(--color-brand-container)',
        },
        path: {
          wifi: 'var(--color-path-wifi)',
          tunnel: 'var(--color-path-tunnel)',
          relay: 'var(--color-path-relay)',
          offline: 'var(--color-path-offline)',
          error: 'var(--color-path-error)',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
      borderRadius: {
        card: '16px',
        chip: '12px',
        pill: '9999px',
        sheet: '28px',
      },
      animation: {
        'pulse-soft': 'pulse-soft 1.2s ease-in-out infinite',
        'blink': 'blink 1s step-end infinite',
        'fade-in': 'fade-in 300ms ease-out',
        'slide-up': 'slide-up 250ms cubic-bezier(0.32, 0.72, 0, 1)',
        'slide-in-right': 'slide-in-right 300ms cubic-bezier(0.32, 0.72, 0, 1)',
      },
      keyframes: {
        'pulse-soft': {
          '0%, 100%': { opacity: '1' },
          '50%': { opacity: '0.4' },
        },
        'blink': {
          '0%, 100%': { opacity: '1' },
          '50%': { opacity: '0' },
        },
        'fade-in': {
          from: { opacity: '0' },
          to: { opacity: '1' },
        },
        'slide-up': {
          from: { transform: 'translateY(100%)' },
          to: { transform: 'translateY(0)' },
        },
        'slide-in-right': {
          from: { transform: 'translateX(30px)', opacity: '0' },
          to: { transform: 'translateX(0)', opacity: '1' },
        },
      },
    },
  },
  plugins: [],
};
